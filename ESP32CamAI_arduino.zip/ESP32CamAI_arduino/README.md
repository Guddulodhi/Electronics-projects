# ESP32-CAM Simple AI Robot #

## Demonstration


## Dependencies
Download https://github.com/Links2004/arduinoWebSockets as zip file and add this library to your Arduino Libraries by Sketch/Include Library/Add Zip...<br/>


## LICENSE
The part contains my code is released under BSD 2-Clause License. Regarding other libraries used in this project, please follow the respective Licenses.